package com.urlshortenerh2.urlshortenerh2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Urlshortenerh2Application {

	public static void main(String[] args) {
		SpringApplication.run(Urlshortenerh2Application.class, args);
	}

}

package com.urlshortenerh2.urlshortenerh2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Urlshortenerh2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

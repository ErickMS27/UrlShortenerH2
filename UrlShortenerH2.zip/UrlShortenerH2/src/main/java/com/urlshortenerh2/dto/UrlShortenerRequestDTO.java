package com.urlshortenerh2.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UrlShortenerRequestDTO {
    private String longLink;

}